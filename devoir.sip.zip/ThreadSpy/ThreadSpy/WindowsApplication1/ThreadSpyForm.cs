using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace ThreadSpy
{
    public partial class ThreadSpyForm : Form
    {
        private Thread drawingThread;
        private TextBox tb;
        private char c = (char)('a'- 1);
        private int NrOfChar = 0;
        public ThreadSpyForm()
        {
            InitializeComponent();
            Runnable(this.TextBoxOutput, c);
        }
         public void Runnable(TextBox tb, char c)
        {
            this.tb = tb;
            this.c = c;
        }

        /// <summary>
        /// This method is called when the user clicks the button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ButtonStartThread_Click(object sender, EventArgs e)
        {
            NrOfChar++;
            c = (char)(c + 1);
            drawingThread = new Thread(() => Run(c, NrOfChar));
            drawingThread.Start();
        }
        
        /// <summary>
        /// This method is called 10 times per second by the timer 
        /// to show the current status of the thread
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (drawingThread != null)
                this.TextBoxStatus.Text = drawingThread.ThreadState.ToString();
        }
        public void Run(char C, int noc)
        {
            for (int i = 0; i < noc; i++)
            {
                Thread.Sleep(300);
                TextBoxHelper.AddChar(tb, C);
            }
        }    
    }
}